function load_content(){
    var main = document.getElementById("stats-container");
    setTimeout(function(){ 
      main.style = 'animation: fadein 1.5s ease 0s forwards;';
    },1000);
  }