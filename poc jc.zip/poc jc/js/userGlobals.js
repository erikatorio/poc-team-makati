var categories = []
var buttons = []
var isClicked = false;
var categoryArray = [];